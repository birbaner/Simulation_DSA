#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import random
import codecs

class Customer:
    def __init__(self, arrival_time):
        self.arrival_time = arrival_time
        self.service_start_time = 0
        self.service_end_time = 0

class Server:
    def __init__(self):
        self.current_customer = None
        self.queue = []
        self.total_service_time = 0

    def is_idle(self):
        return self.current_customer is None

    def enqueue(self, customer):
        self.queue.append(customer)
        
    def update_service_time(self, service_time):
        self.total_service_time += service_time
        

class Simulation:
    def __init__(self, num_servers, arrival_rate, service_rate, simulation_duration, max_iterations):
        self.num_servers = num_servers
        self.arrival_rate = arrival_rate
        self.service_rate = service_rate
        self.simulation_duration = simulation_duration
        self.max_iterations = max_iterations
        self.current_time = 0
        self.customers = []
        self.servers = []
        self.iterations = 0
        self.max_queue_length = 0
        self.total_waiting_time = 0
        self.max_waiting_time = 0
        self.service_occupancy = [0] * num_servers

    def generate_customers(self):
        inter_arrival_time = 1 / self.arrival_rate

        while self.current_time < self.simulation_duration:
            self.current_time += random.expovariate(self.arrival_rate)
            self.customers.append(Customer(self.current_time))

    def generate_service_time(self):
        return random.expovariate(self.service_rate)

    def run_option1_simulation(self):
        self.generate_customers()
        self.servers = [Server() for _ in range(self.num_servers)]

        while self.iterations < self.max_iterations and self.iterations < len(self.customers):
            current_customer = self.customers[self.iterations]

            min_queue_length = float('inf')
            chosen_server = None

            for server in self.servers:
                queue_length = len(server.queue)
                if queue_length < min_queue_length:
                    min_queue_length = queue_length
                    chosen_server = server

            if chosen_server is not None:
                chosen_server.enqueue(current_customer)

                if chosen_server.is_idle():
                    service_time = self.generate_service_time()
                    chosen_server.current_customer = current_customer
                    chosen_server.current_customer.service_start_time = self.current_time
                    chosen_server.current_customer.service_end_time = self.current_time + service_time
                    chosen_server.update_service_time(service_time)
                    
                    
                    self.current_time += service_time

            for server in self.servers:
                if not server.is_idle() and server.current_customer.service_end_time <= self.current_time:
                    server.current_customer = None

            self.iterations += 1
            
            

            # Update simulation results
            queue_lengths = [len(server.queue) for server in self.servers]
            max_queue_length = max(queue_lengths)
            self.max_queue_length = max(self.max_queue_length, max_queue_length)

            if current_customer.service_start_time > current_customer.arrival_time:
                waiting_time = current_customer.service_start_time - current_customer.arrival_time
                self.total_waiting_time += waiting_time
                self.max_waiting_time = max(self.max_waiting_time, waiting_time)
                

    def run_option2_simulation(self, policy):
        self.generate_customers()
        self.servers = [Server() for _ in range(self.num_servers)]

        while self.iterations < self.max_iterations and self.iterations < len(self.customers):
            current_customer = self.customers[self.iterations]

            if policy == "round-robin":
                chosen_server = self.servers[self.iterations % self.num_servers]
            elif policy == "shortest-queue":
                chosen_server = min(self.servers, key=lambda server: len(server.queue))
            elif policy == "random":
                chosen_server = random.choice(self.servers)
            else:
                raise ValueError("Invalid policy")

            chosen_server.enqueue(current_customer)

            if chosen_server.is_idle():
                service_time = self.generate_service_time()
                chosen_server.current_customer = current_customer
                chosen_server.current_customer.service_start_time = self.current_time
                chosen_server.current_customer.service_end_time = self.current_time + service_time
                chosen_server.update_service_time(service_time)
                
                self.current_time += service_time

            for server in self.servers:
                if not server.is_idle() and server.current_customer.service_end_time <= self.current_time:
                    server.current_customer = None

            self.iterations += 1

            # Update simulation results
            queue_lengths = [len(server.queue) for server in self.servers]
            max_queue_length = max(queue_lengths)
            self.max_queue_length = max(self.max_queue_length, max_queue_length)

            if current_customer.service_start_time > current_customer.arrival_time:
                waiting_time = current_customer.service_start_time - current_customer.arrival_time
                self.total_waiting_time += waiting_time
                self.max_waiting_time = max(self.max_waiting_time, waiting_time)

    def get_max_queue_length(self):
        return self.max_queue_length

    def get_average_waiting_time(self):
        return self.total_waiting_time / self.iterations

    def get_max_waiting_time(self):
        return self.max_waiting_time
    
    def get_service_occupancy_rates(self):
        occupancy_rates = []
        for server in self.servers:
            occupancy_rate = (server.total_service_time / self.simulation_duration) * 100
            occupancy_rates.append(f"{occupancy_rate:.2f}%")
        return occupancy_rates
    

# Open the file with appropriate encoding to handle BOM
with codecs.open("Rupsa_testfile_0704.txt", "r", encoding="utf-8-sig") as file:
    lines = file.readlines()
    
# Create a new file to write the output
output_file = open("output_0704.txt", "w")


# Process each set of input values
index = 0
while index + 2 < len(lines):
    # Read the input values for the current set
    simulation_duration = int(lines[index].strip())
    arrival_rate = float(lines[index + 1].strip())
    service_rate = float(lines[index + 2].strip())
    num_servers = 5
    max_iterations = 100
    
    
    # Calculate the service rate (customers per time unit)
    service_rate = 1 / service_rate

    # Option 1 Simulation
    sim1 = Simulation(num_servers, arrival_rate, service_rate, simulation_duration, max_iterations)
    sim1.run_option1_simulation()

    # Option 2 Simulation - Round-robin Policy
    sim2_rr = Simulation(num_servers, arrival_rate, service_rate, simulation_duration, max_iterations)
    sim2_rr.run_option2_simulation("round-robin")

    # Option 2 Simulation - Shortest-queue Policy
    sim2_sq = Simulation(num_servers, arrival_rate, service_rate, simulation_duration, max_iterations)
    sim2_sq.run_option2_simulation("shortest-queue")

    # Option 2 Simulation - Random Policy
    sim2_rand = Simulation(num_servers, arrival_rate, service_rate, simulation_duration, max_iterations)
    sim2_rand.run_option2_simulation("random")

    # Conversion factor from time units to minutes
    time_unit_to_minutes = 60

    # Write the output to the file
    with open("output_0704.txt", "a") as output_file:
        output_file.write("Option 1 Simulation Results:\n")
        output_file.write(f"Max Queue Length: {sim1.get_max_queue_length()}\n")
        output_file.write(f"Average Waiting Time: {sim1.get_average_waiting_time() / time_unit_to_minutes:.2f} minutes\n")
        output_file.write(f"Max Waiting Time: {sim1.get_max_waiting_time() / time_unit_to_minutes:.2f} minutes\n")
        output_file.write(f"Service Occupancy Rates: {', '.join(sim1.get_service_occupancy_rates())}\n\n")

        output_file.write("Running Option 2 Simulation with Round-robin Policy...\n")
        output_file.write("Option 2 (Round-robin) Simulation Results:\n")
        output_file.write(f"Max Queue Length: {sim2_rr.get_max_queue_length()}\n")
        output_file.write(f"Average Waiting Time: {sim2_rr.get_average_waiting_time() / time_unit_to_minutes:.2f} minutes\n")
        output_file.write(f"Max Waiting Time: {sim2_rr.get_max_waiting_time() / time_unit_to_minutes:.2f} minutes\n")
        output_file.write(f"Service Occupancy Rates: {', '.join(sim2_rr.get_service_occupancy_rates())}\n\n")

        output_file.write("Running Option 2 Simulation with Shortest-queue Policy...\n")
        output_file.write("Option 2 (Shortest-queue) Simulation Results:\n")
        output_file.write(f"Max Queue Length: {sim2_sq.get_max_queue_length()}\n")
        output_file.write(f"Average Waiting Time: {sim2_sq.get_average_waiting_time() / time_unit_to_minutes:.2f} minutes\n")
        output_file.write(f"Max Waiting Time: {sim2_sq.get_max_waiting_time() / time_unit_to_minutes:.2f} minutes\n")
        output_file.write(f"Service Occupancy Rates: {', '.join(sim2_sq.get_service_occupancy_rates())}\n\n")

        output_file.write("Running Option 2 Simulation with Random Policy...\n")
        output_file.write("Option 2 (Random) Simulation Results:\n")
        output_file.write(f"Max Queue Length: {sim2_rand.get_max_queue_length()}\n")
        output_file.write(f"Average Waiting Time: {sim2_rand.get_average_waiting_time() / time_unit_to_minutes:.2f} minutes\n")
        output_file.write(f"Max Waiting Time: {sim2_rand.get_max_waiting_time() / time_unit_to_minutes:.2f} minutes\n")
        output_file.write(f"Service Occupancy Rates: {', '.join(sim2_rand.get_service_occupancy_rates())}\n\n")
        
        # Get the simulation results
        print("Option 1 Simulation Results:")
        print(f"Max Queue Length: {sim1.get_max_queue_length()}") #using f values are inserted in the string
        print(f"Average Waiting Time: {sim1.get_average_waiting_time()/ time_unit_to_minutes:.2f} minutes")
        print(f"Max Waiting Time: {sim1.get_max_waiting_time()/ time_unit_to_minutes:.2f} minutes")
        print(f"Service Occupancy Rates: {sim1.get_service_occupancy_rates()}")  # Option 1 occupancy rates
        
        print("\nRunning Option 2 Simulation with Round-robin Policy...")
        print("Option 2 (Round-robin) Simulation Results:")
        print(f"Max Queue Length: {sim2_rr.get_max_queue_length()}")
        print(f"Average Waiting Time: {sim2_rr.get_average_waiting_time()/ time_unit_to_minutes:.2f} minutes")
        print(f"Max Waiting Time: {sim2_rr.get_max_waiting_time()/ time_unit_to_minutes:.2f} minutes")
        print(f"Service Occupancy Rates: {sim2_rr.get_service_occupancy_rates()}")  # Option 2 (Round-robin) occupancy rates
        
        print("\nRunning Option 2 Simulation with Shortest-queue Policy...")
        print("Option 2 (Shortest-queue) Simulation Results:")
        print(f"Max Queue Length: {sim2_sq.get_max_queue_length()}")
        print(f"Average Waiting Time: {sim2_sq.get_average_waiting_time()/ time_unit_to_minutes:.2f} minutes")
        print(f"Max Waiting Time: {sim2_sq.get_max_waiting_time()/ time_unit_to_minutes:.2f} minutes")
        print(f"Service Occupancy Rates: {sim2_sq.get_service_occupancy_rates()}")  # Option 2 (Shortest-queue) occupancy rates
        
        print("\nRunning Option 2 Simulation with Random Policy...")
        print("Option 2 (Random) Simulation Results:")
        print(f"Max Queue Length: {sim2_rand.get_max_queue_length()}")
        print(f"Average Waiting Time: {sim2_rand.get_average_waiting_time()/ time_unit_to_minutes:.2f} minutes")
        print(f"Max Waiting Time: {sim2_rand.get_max_waiting_time()/ time_unit_to_minutes:.2f} minutes")
        print(f"Service Occupancy Rates: {sim2_rand.get_service_occupancy_rates()}")  # Option 2 (Random) occupancy rates
        
        # Move to the next set of input values
        index += 3

# Close the output file
output_file.close()

