﻿
SPECIAL COMMAND: in Mobaxterm

Making .tar file:

cd /afs/cad.njit.edu/u/r/b/rb757/Rupsa_simulation_final_0704


tar -cvf simulation_0704.tar source_code_simulation_0704.py README-0704.txt  output_0704.txt  Rupsa_testfile_0704.txt


untar the tar file:

tar -xvf simulation_0704.tar

check the output file:

cat output_0704.txt




